import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  await page.goto('https://www.volenday.com/');
  await page.getByRole('link', { name: 'Get In Touch' }).click();
  await page.getByLabel('First Name').click();
  await page.getByLabel('First Name').fill('heychad123');
  await page.getByLabel('First Name').press('Tab');
  await page.getByLabel('Last Name').press('Tab');
  await page.getByLabel('Email').fill('hasdfadf123@....');
  await page.getByLabel('Phone Number').click();
  await page.getByLabel('Phone Number').fill('+63 321112333212333');
  await page.getByLabel('Recruitment Service').check();
  await page.getByLabel('Write Your Message').click();
  await page.getByLabel('Write Your Message').fill('hey');
});