// const {test, expect} = require('@playwright/test')

import {test, expect} from '@playwright/test'

test('Locators', async ({page})=>{

    await page.goto("https://www.volenday.com")

    //click on Get In Touch button -property of an element as a locator
    await page.click("div[class='extra-buttons MuiBox-root css-6k8fz8'] div[class='MuiBox-root css-14p9h1f']")

    //provide firstname - XPath
    await page.fill("//input[@id=':r2:']",'heychade@1312')

    //provide last name - XPath
    await page.fill("//input[@id=':r3:']",'hjkwer!@#123')

    //Click on Send Message button - XPath
    await page.click("//div[@class='MuiBox-root css-fsk0iz']")

    //verify Our Business presence - XPath
    const ourBusiness = await page.locator("//a[contains(text(),'Our Businesses')]")

    await expect(ourBusiness).toBeVisible();

    await page.close();

})