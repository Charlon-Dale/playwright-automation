import { test, expect } from '@playwright/test';

test('assertionsTest', async ({page})=>{

    await page.goto('https://www.volenday.com/contact-us')
    await expect(page).toHaveURL('https://www.volenday.com/contact-us')


    await expect(page).toHaveTitle('B2B Staffing, Custom Software and Process Management Solutions')

    const logoElement = page.locator("//div[@class='MuiContainer-root css-1m2bsmt']//img[@title='Volenday Group Logo']")
    await expect(logoElement).toBeVisible()

    const getInTouch = await page.locator("//div[@class='extra-buttons MuiBox-root css-6k8fz8']//div[@role='button']")
    await expect(getInTouch).toBeEnabled()

    const generalInquiryCheckbox = await page.locator("//input[@value='General Inquiry']")
    await generalInquiryCheckbox.click()
    await expect(generalInquiryCheckbox).toBeChecked()

    const recruitmentServiceCheckbox = await page.locator("//input[@value='Recruitment Service']")
    await expect(recruitmentServiceCheckbox).not.toBeChecked()

    const sendMessageButton = await page.locator("//div[@class='MuiBox-root css-1joff3j']")
    await expect(sendMessageButton).toHaveAttribute('role','button')
    
    await expect(await page.locator("//h3[normalize-space()='Contact Information']")).toHaveText('Contact Information')

    await expect(await page.locator("//h3[normalize-space()='Contact Information']")).toContainText('Contact')

    const emailInput = await page.locator("//input[@id=':r2:']")
    await emailInput.fill('test123@gmas.asdf')
    await expect(emailInput).toHaveValue('test123@gmas.asdf')

})