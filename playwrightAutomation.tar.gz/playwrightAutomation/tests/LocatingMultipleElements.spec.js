import {test, expect} from '@playwright/test'

test('LocateMultipleElements', async ({page}) => {

   await page.goto('https://www.volenday.com')

    //    const links = await page.$$('a');

    //    for(const link of links) 
    //    {
    //         const linktext = await link.textContent();
    //         console.log(linktext);
    //    }

    //show executive names 
    page.waitForSelector("//p[@class='MuiTypography-root MuiTypography-body1 css-kniqbl']")
    const executives = await page.$$("//p[@class='MuiTypography-root MuiTypography-body1 css-kniqbl']")

    for(const executive of executives)
    {
        const executiveName = await executive.textContent()
        console.log(executiveName)
    }
})