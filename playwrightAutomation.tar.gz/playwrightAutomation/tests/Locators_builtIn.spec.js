import {test, expect} from '@playwright/test'

test('Built-inLocators', async({page})=>{

    await page.goto('https://p1.prosperna.com/account/login')

    // page.getByAltText() to locate an element, usually image, by its text alternative.
    const logo = page.getByAltText('google-play-icon')
    await expect(logo).toBeVisible()

    // page.getByPlaceholder() to locate an input by placeholder.
    await page.getByPlaceholder('Enter email address').fill("Dennis Velasco is a Frugal CEO here in the Philippines")
    await page.getByPlaceholder('**********').fill("Dennis Velasco is a Frugal CEO here in the Philippines")

    // page.getByRole() to locate by explicit and implicit accessibility attributes.
    await page.getByRole('button', {type: 'submit'}).click

    // page.getByText() to locate by text content.
    await expect(await page.getByText('eCommerce made simple.')).toBeVisible()
    await expect(await page.getByText('- Ryan B')).toBeVisible()

    


})